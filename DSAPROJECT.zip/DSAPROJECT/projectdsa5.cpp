#include <iostream>
#include <string>
using namespace std;

class Node 
{
private:
	int data;
	Node* next;

public:
	Node(int val = 0) 
	{
		data = val;
		next = NULL;
	}

	int getData()
	{
		return data; 
	}

	void setData(int val) 
	{
		data = val;
	}

	Node* getNext()
	{
		return next; 
	}

	void setNext(Node* ptr) 
	{
		next = ptr; 
	}
};

class Queue 
{
private:
	Node* front;
	Node* rear;

public:
	Queue() 
	{
		front = NULL;
		rear = NULL;
	}

	~Queue() 
	{
		Node* temp = front;
		while (front != NULL) 
		{
			front = front->getNext();
			delete temp;
			temp = front;
		}
		rear = NULL;
	}

	void Enqueue(int val) 
	{
		Node* newNode = new Node(val);
		if (isEmpty()) 
		{
			front = newNode;
			rear = newNode;
		}
		else
		{
			rear->setNext(newNode);
			rear = newNode;
		}
	}

	int Dequeue()
	{
		if (isEmpty()) 
		{
			cout << "Queue underflow!" << endl;
			return -1;
		}
		int val = front->getData();
		Node* temp = front;
		front = front->getNext();
		delete temp;
		if (front == NULL) 
		{
			rear = NULL;
		}
		return val;
	}

	bool isEmpty() 
	{
		return (front == NULL);
	}

	int size() 
	{
		int count = 0;
		Node* temp = front;
		while (temp != NULL) 
		{
			count++;
			temp = temp->getNext();
		}
		return count;
	}

	void display() 
	{
		if (isEmpty()) 
		{
			cout << "Queue is empty!" << endl;
			return;
		}
		cout << "Queue: ";
		Node* temp = front;
		while (temp != NULL) 
		{
			cout << temp->getData() << " ";
			temp = temp->getNext();
		}
		cout << endl;
	}

	void reverseQueue() 
	{
		if (isEmpty()) 
		{
			cout << "Queue is empty!" << endl;
			return;
		}
		Node* prev = NULL;
		Node* current = front;
		Node* next = NULL;

		rear = front; 
		while (current != NULL) 
		{
			next = current->getNext(); 
			current->setNext(prev);    
			prev = current;
			current = next;
		}

		front = prev;
	}
};

class FlightInformation
{
private:
	string flightNumber;
	string departureTime;
	string arrivalTime;
	int availableSeats;

public:
	FlightInformation(string number, string departure, string arrival, int seats)
	{

		flightNumber = number;
		departureTime = departure;
		arrivalTime = arrival;
		availableSeats = seats;
	}

	string getFlightNumber() const 
	{
		return flightNumber;
	}

	string getDepartureTime() const 
	{
		return departureTime;
	}

	string getArrivalTime() const 
	{
		return arrivalTime;
	}

	int getAvailableSeats() const 
	{
		return availableSeats;
	}

	void setDepartureTime(string departure) 
	{
		departureTime = departure;
	}

	void setArrivalTime(string arrival) 
	{
		arrivalTime = arrival;
	}

	void updateAvailableSeats(int seats) 
	{
		availableSeats = seats;
	}

	void displayFlightInfo() const 
	{
		cout << "Flight Number: " << flightNumber << "\n"
			<< "Departure Time: " << departureTime << "\n"
			<< "Arrival Time: " << arrivalTime << "\n"
			<< "Available Seats: " << availableSeats << "\n\n";
	}
};

class PassengerBookingSystem 
{
private:
	Queue bookingQueue;

public:
	void bookFlight(int passengerID) 
	{
		bookingQueue.Enqueue(passengerID);
		cout << "Passenger with ID " << passengerID << " booked the flight.\n";
	}

	void processBookings() 
	{
		while (!bookingQueue.isEmpty()) 
		{
			int passengerID = bookingQueue.Dequeue();
			cout << "Processing booking for Passenger with ID " << passengerID << ".\n";
		}
		cout << "All bookings processed.\n";
	}

	void displayBookings() 
	{
		bookingQueue.display();
	}
};

class FlightHistoryNode 
{
public:
	string flightNumber;
	string seatAssignment;
	string travelDate;
	FlightHistoryNode* next;
	FlightHistoryNode* prev;

	FlightHistoryNode(const string& flightNum, const string& seatAssign, const string& date)
	{
		flightNumber = flightNum;
		seatAssignment = seatAssign;
		travelDate = date;
		next = nullptr;
		prev = nullptr;
	}
};

class FlightHistoryList 
{
private:
	FlightHistoryNode* head;

public:
	FlightHistoryList()
	{
		head = nullptr;
	}

	void addFlightHistory(const string& flightNumber, const string& seatAssignment, const string& travelDate) {
		FlightHistoryNode* newNode = new FlightHistoryNode(flightNumber, seatAssignment, travelDate);

		if (head == nullptr) 
		{
			head = newNode;
		}
		else 
		{
			newNode->next = head;
			head->prev = newNode;
			head = newNode;
		}

		cout << "Flight history added for passenger.\n";
	}

	void displayFlightHistory() const 
	{
		FlightHistoryNode* current = head;
		cout << "Flight History:\n";
		while (current != nullptr) 
		{
			cout << "Flight Number: " << current->flightNumber << ", Seat Assignment: " << current->seatAssignment
				<< ", Travel Date: " << current->travelDate << "\n";
			current = current->next;
		}
		cout << "\n";
	}
};

class AirlineReservationSystem 
{
private:
	PassengerBookingSystem passengerBookingSystem;
	FlightHistoryList flightHistoryList;

public:
	void displayMenu() 
	{
		cout << "\n==============================\n";
		cout << "Airline Reservation System\n";
		cout << "==============================\n";
		cout << "1. Book Flight\n";
		cout << "2. Process Bookings\n";
		cout << "3. Display Current Bookings\n";
		cout << "4. Add Flight History\n";
		cout << "5. Display Flight History\n";
		cout << "6. Exit\n";
	}

	void run() 
	{
		int choice;
		do {
			displayMenu();
			cout << "Enter your choice (1-6): ";
			cin >> choice;

			switch (choice) 
			{
			case 1: 
			{
						int passengerID;
						string flightNumber;
						cout << "Enter Passenger ID: ";
						cin >> passengerID;
						cout << "Enter Flight Number: ";
						cin >> flightNumber;
						bookFlight(passengerID, flightNumber);
						break;
			}
			case 2:
				processBookings();
				break;
			case 3:
				displayBookings();
				break;
			case 4: 
			{
						int passengerID;
						string flightNumber, seatAssignment, travelDate;
						cout << "Enter Passenger ID: ";
						cin >> passengerID;
						cout << "Enter Flight Number: ";
						cin >> flightNumber;
						cout << "Enter Seat Assignment: ";
						cin >> seatAssignment;
						cout << "Enter Travel Date: ";
						cin >> travelDate;
						addFlightHistory(passengerID, flightNumber, seatAssignment, travelDate);
						break;
			}
			case 5:
				displayFlightHistory();
				break;
			case 6:
				cout << "Exiting the program.\n";
				break;
			default:
				cout << "Invalid choice. Please enter a number between 1 and 6.\n";
			}

		} while (choice != 6);
	}

	void bookFlight(int passengerID, const string& flightNumber) 
	{
		passengerBookingSystem.bookFlight(passengerID);
	}

	void processBookings() 
	{
		passengerBookingSystem.processBookings();
	}

	void displayBookings() 
	{
		cout << "\nCurrent Passenger Bookings:\n";
		passengerBookingSystem.displayBookings();
	}

	void addFlightHistory(int passengerID, const string& flightNumber, const string& seatAssignment, const string& travelDate) 
	{
		flightHistoryList.addFlightHistory(flightNumber, seatAssignment, travelDate);
	}

	void displayFlightHistory() const 
	{
		cout << "\nFlight History:\n";
		flightHistoryList.displayFlightHistory();
	}
};

int main() 
{
	AirlineReservationSystem airlineSystem;
	airlineSystem.run();
	return 0;
}
